# Process and Scripts for Setting Up TomTom Data Schemas
The Data & Visualization group updates the base data it receives from TomTom on an annual basis. This section contains the processes and scripts used to create the TomTom source schema, import the feature and attribute data, and configure the tables.
