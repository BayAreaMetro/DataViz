*	The Open Data manager, will work with the data creator to determine which license to apply to data and add it to metadata information along with agency disclaimer.
*	The Open Data manager, will work with data creator to determine how data will be made availble to public (download only, generic feature service, symbolized feature set, web map, multiple subsets, etcetera).
