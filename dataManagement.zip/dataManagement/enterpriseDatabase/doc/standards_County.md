## County Values
All enterprise data sets should use the following attribute values for county designations:

Value | County
------|------
6001 | Alameda
6013 | Contra Costa
6041 | Marin
6055 | Napa
6075 | San Francisco
6081 | San Mateo
6085 | Santa Clara
6095 | Solano
6097 | Sonoma
